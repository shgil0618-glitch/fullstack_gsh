package com.thejoa703;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Boot002Application {

	public static void main(String[] args) {
		SpringApplication.run(Boot002Application.class, args);
	}

}
