package com.thejoa703.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BasicDto {
	private String name;
	private int age;
}
