#1. project 만들기


Q. boot002번으로 프로젝트 만들기
- java 11
- port 9494
- db설정

#2. ~ service 작성 및 테스트 완료