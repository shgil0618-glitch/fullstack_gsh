package com.thejoa703.dto.request;

import lombok.Getter;
import lombok.Setter;

//DeptUserUpdateRequestDto.java
@Getter
@Setter
public class DeptUserUpdateRequestDto {
 private String dname;
 private String loc;

 // getter, setter
}
