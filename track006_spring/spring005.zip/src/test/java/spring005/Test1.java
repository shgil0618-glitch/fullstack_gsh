package spring005;


import java.net.InetAddress;
import java.net.UnknownHostException;
import java.security.Provider.Service;
import java.util.HashMap;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSession;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.thejoa703.dao.SboardDao;
import com.thejoa703.dto.SboardDto;
import com.thejoa703.service.SboardService;
import com.thejoa703.service.SboardServiceImpl;



@RunWith(SpringJUnit4ClassRunner.class)		//1. spring �����׽�Ʈ
@ContextConfiguration(locations = "classpath:config/root-context.xml")	//2. ����
public class Test1 {
	
	@Autowired  ApplicationContext context; //3. ioc - Bean (�������� �����ϴ� ��ü) ����~�Ҹ�
	@Autowired  DataSource   ds;
	@Autowired  SqlSession   session;
	@Autowired  SboardDao   dao;
	@Autowired  SboardService service;
	
	@Ignore @Test public void test1() { System.out.println(context); }
	@Ignore @Test public void test2() { System.out.println(ds);      }
	@Ignore @Test public void test3() { System.out.println(session);      }
	
	@Ignore @Test public void test5() throws UnknownHostException { 
		// 5. 
		//		Sboard1Dto dto = new Sboard1Dto();
		//		dto.setId(41);   dto.setBpass("1"); ie
		//		System.out.println(service.delete(dto));
		// 4. 
		//		Sboard1Dto dto = new Sboard1Dto();
		//    	dto.setAppUserId(24);  dto.setBtitle("title-new");   dto.setBcontent("content-new");  dto.setBpass("1");   dto.setId(41);
		//    	System.out.println(service.update(dto));
		// 3.
		//System.out.println(service.select(28));
		
		//		//  2. insert  	
		//				Sboard1Dto dto = new Sboard1Dto();
		//		    	dto.setAppUserId(24);  dto.setBtitle("title");   dto.setBcontent("content");  dto.setBpass("1"); 
		//		    	System.out.println(service.insert(dto));
		  //  1. selectAll
		 System.out.println(service.selectAll());
	}
	
	@Ignore @Test public void test4() throws UnknownHostException { 
    	//5. delete
//    	Sboard1Dto dto = new Sboard1Dto(); 
//    	dto.setBpass("1111");  dto.setId(5);
//    	System.out.println(dao.delete(dto));
    	
    	//4. update
//    	Sboard1Dto dto = new Sboard1Dto(); 
//    	dto.setBtitle("title-new");   dto.setBcontent("content-new");  dto.setBpass("1111");  dto.setId(5);
//    	System.out.println(dao.update(dto));
    	
    	//3. select
//   	    System.out.println(service.select(28));
    	
    	//2. insert
//    	SboardDto dto = new SboardDto();
//    	dto.setAppUserId(24);  dto.setBtitle("title");   dto.setBcontent("content");  dto.setBpass("1111");
//    	dto.setBip(  InetAddress.getLocalHost().getHostAddress()  ); 
//    	
//    	System.out.println(dto);
//    	
//    	System.out.println(dao.insert(dto));
//    	
//    	//1. selectAll
//   	    System.out.println(dao.selectAll());
   }
	@Test public void test7() {
		HashMap<String,String> para = new HashMap<>();
		para.put("search", "%t%");
		
		System.out.println(dao.selectSearch(para));
	}

}
