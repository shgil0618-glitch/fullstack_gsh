package com.thejoa703.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.thejoa703.dto.UserDto;

@MyDao
public interface UserDao {

    public int insert(UserDto dto);
    public int update(UserDto dto);
    public int delete(UserDto dto);
    public List<UserDto> selectAll();
    public UserDto select(int appUserId);
    public UserDto login(UserDto dto); // �̸���, ��й�ȣ�� �α��� ó��
    
    //�̹��� �߰�
    public int insert2(UserDto dto);
    public int update2(UserDto dto);
    
	/* iddoutble */
    public int iddouble(String email);
    
    /*������ ���� ��ȸ*/
    public int deleteAdmin(UserDto dto);
    public int updateAdmin(UserDto dto);
    
}
