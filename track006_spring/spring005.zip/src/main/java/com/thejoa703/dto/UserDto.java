package com.thejoa703.dto;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDto {
    private int appUserId;          // PK
    private String email;           // �̸���
    private String password;        // ��й�ȣ
    private Integer mbtiTypeId;     // MBTI Ÿ��
    
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createdAt; // ������
    
    private String ufile;
}
