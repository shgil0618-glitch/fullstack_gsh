package com.thejoa703.dao;

public @interface MbtiDao {

}
