package project2.controller;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import project2.dto.RecipeDto;
import project2.service.RecipeService;
import project2.service.AppUserSecurityService; // 사용자 정보를 가져오기 위해 필요할 수 있음

@Controller
@RequestMapping("/recipe/*")
public class RecipeController {
	
	@Autowired 
	RecipeService recipeService;
	
	@Autowired
	AppUserSecurityService userService; // 작성자 닉네임 등을 가져올 때 필요

	// --- 1. R E A D (조회) ---

	/**
	 * 레시피 전체 목록 페이지 (메인 페이지)
	 */
	@GetMapping("/list")
	public String list(Model model) {
		// 페이징 처리가 없다면 모든 레시피를 가져옵니다.
		List<RecipeDto> recipeList = recipeService.selectAllRecipes();
		model.addAttribute("list", recipeList);
		return "/recipe/list"; // JSP 경로 예시
	}

	/**
	 * 레시피 상세 조회 페이지
	 */
	@GetMapping("/detail")
	public String detail(@RequestParam("recipeId") int recipeId, Model model) {
		RecipeDto recipe = recipeService.selectRecipeDetail(recipeId);
		
		if (recipe == null) {
			// 레시피가 없는 경우 404 페이지나 목록 페이지로 리다이렉트
			return "redirect:/recipe/list";
		}
		
		model.addAttribute("recipe", recipe);
		return "/recipe/detail"; // JSP 경로 예시
	}
	
	/**
	 * 내가 작성한 레시피 목록 (마이페이지에서 사용)
	 */
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/mylist")
	public String myList(Principal principal, Model model) {
		// Principal에서 로그인한 사용자의 APPUSERID를 찾아야 합니다.
		// 이 예시에서는 Principal.getName()이 email이라고 가정하고, email로 APPUSERID를 찾습니다.
		
		String email = principal.getName();
		
		// 1. DTO를 통해 AppUser ID 조회
		// (실제로는 로그인 세션/인증 객체에서 AppUser ID를 직접 가져오는 것이 가장 효율적입니다.)
		int appUserId = userService.selectEmail(email).getAppUserId(); 
		
		// 2. 내가 쓴 레시피 조회
		List<RecipeDto> myList = recipeService.selectMyRecipes(appUserId);
		model.addAttribute("list", myList);
		
		return "/recipe/mylist"; // JSP 경로 예시
	}


	// --- 2. C R E A T E (등록) ---

	/**
	 * 레시피 등록 폼 페이지
	 */
	@PreAuthorize("isAuthenticated()") // 로그인한 사용자만 등록 가능
	@GetMapping("/register")
	public String registerForm() {
		return "/recipe/register"; // JSP 경로 예시
	}

	/**
	 * 레시피 등록 처리
	 */
	@PreAuthorize("isAuthenticated()")
	@PostMapping(value = "/register", headers = ("content-type=multipart/*"))
	public String register(
		RecipeDto dto,
		@RequestParam("recipeFiles") List<MultipartFile> files,
		Principal principal,
		RedirectAttributes rttr) {

		// 1. Principal에서 작성자 ID를 DTO에 설정 (로그인 사용자 정보 활용)
		// (실제로는 로그인 세션/인증 객체에서 AppUser ID를 직접 가져와야 합니다.)
		String email = principal.getName();
		int appUserId = userService.selectEmail(email).getAppUserId();
		dto.setAppUserId(appUserId);
		
		// 2. 서비스 호출 (파일 처리 및 DB 삽입)
		String resultMessage = "레시피 등록 실패";
		try {
			if (recipeService.insertRecipe(dto, files) > 0) {
				resultMessage = "레시피 등록 성공";
			}
		} catch (Exception e) {
			e.printStackTrace();
			// 파일 저장 또는 DB 트랜잭션 오류 발생 시
			resultMessage = "레시피 등록 중 서버 오류 발생"; 
		}

		rttr.addFlashAttribute("result", resultMessage);
		return "redirect:/recipe/list";
	}


	// --- 3. U P D A T E (수정) ---

	/**
	 * 레시피 수정 폼 페이지
	 */
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/modify")
	public String modifyForm(@RequestParam("recipeId") int recipeId, Principal principal, Model model) {
		RecipeDto recipe = recipeService.selectRecipeDetail(recipeId);
		
		// 1. 권한 확인: 현재 로그인 사용자가 작성자인지 확인
		String email = principal.getName();
		int currentUserId = userService.selectEmail(email).getAppUserId();
		
		if (recipe == null || recipe.getAppUserId() != currentUserId) {
			// 권한이 없거나 레시피가 없는 경우
			return "redirect:/recipe/detail?recipeId=" + recipeId;
		}
		
		model.addAttribute("recipe", recipe);
		return "/recipe/modify"; // JSP 경로 예시
	}

	/**
	 * 레시피 수정 처리
	 */
	@PreAuthorize("isAuthenticated()")
	@PostMapping(value = "/modify", headers = ("content-type=multipart/*"))
	public String modify(
		RecipeDto dto,
		@RequestParam("recipeFiles") List<MultipartFile> files,
		Principal principal,
		RedirectAttributes rttr) {

		// 1. DTO에 현재 로그인 사용자 ID 설정 (Service에서 권한 확인을 위해 사용)
		String email = principal.getName();
		int currentUserId = userService.selectEmail(email).getAppUserId();
		dto.setAppUserId(currentUserId);
		
		String resultMessage = "레시피 수정 실패 (권한 없음 또는 비밀번호 오류)";
		
		try {
			if (recipeService.updateRecipe(dto, files) > 0) {
				resultMessage = "레시피 수정 성공";
			}
		} catch (Exception e) {
			e.printStackTrace();
			resultMessage = "레시피 수정 중 오류 발생"; 
		}
		
		rttr.addFlashAttribute("result", resultMessage);
		return "redirect:/recipe/detail?recipeId=" + dto.getRecipeId();
	}


	// --- 4. D E L E T E (삭제) ---

	/**
	 * 레시피 삭제 처리
	 */
	@PreAuthorize("isAuthenticated()")
	@PostMapping("/delete")
	public String deleteRecipe(
		@RequestParam("recipeId") int recipeId,
		Principal principal,
		RedirectAttributes rttr) {

		// 1. Principal에서 사용자 ID 설정
		String email = principal.getName();
		int currentUserId = userService.selectEmail(email).getAppUserId();

		String resultMessage = "레시피 삭제 실패";
		
		try {
			if (recipeService.deleteRecipe(recipeId, currentUserId) > 0) {
				resultMessage = "레시피 삭제 성공";
			} else {
				// 삭제 실패 (Service에서 권한 확인 로직을 통과하지 못했을 경우)
				resultMessage = "레시피 삭제 권한이 없습니다.";
			}
		} catch (Exception e) {
			e.printStackTrace();
			resultMessage = "레시피 삭제 중 오류 발생";
		}
		
		rttr.addFlashAttribute("result", resultMessage);
		return "redirect:/recipe/list";
	}
}