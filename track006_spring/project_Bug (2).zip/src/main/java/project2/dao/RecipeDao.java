package project2.dao;

import java.util.List;

import project2.dto.RecipeDto;
import project2.dto.RecipeImage;
import project2.dto.RecipeIngre;
import project2.dto.RecipeIngreMap;

@MyDao
public interface RecipeDao {
	// 1. **C R E A T E (등록)**
    /** 레시피 기본 정보를 등록하고 생성된 RECIPE_ID를 DTO에 반환합니다. */
    public int insert(RecipeDto dto);
    
    /** 레시피 이미지를 등록합니다. */
    public int insertRecipeImage(RecipeImage image);

    /** 재료 매핑 정보를 등록하고 생성된 INGRE_MAP_ID를 Map DTO에 반환합니다. */
    public int insertIngredientMap(RecipeIngreMap ingreMap);

    /** 재료 상세 정보를 등록합니다. */
    public int insertIngredientDetail(RecipeIngre ingre);
    
    // ---
    
    // 2. **R E A D (조회)**
    
    /** 전체 레시피 목록을 최신 순으로 조회합니다. */
    public List<RecipeDto> selectAll();
    
    /** 특정 사용자(appUserId)가 작성한 레시피 목록을 조회합니다. */
    public List<RecipeDto> selectMyRecipes(int appUserId);

    /** 특정 RECIPE_ID의 레시피 상세 정보를 조회합니다. */
    public RecipeDto select(int recipeId);
    
    /** 특정 레시피의 이미지 목록을 조회합니다. */
    public List<RecipeImage> selectRecipeImages(int recipeId);
    
    /** 특정 레시피의 재료 목록을 조회합니다. */
    public List<RecipeIngre> selectRecipeIngredients(int recipeId);

    /** 레시피 조회수를 1 증가시킵니다. */
    public int incrementRecipeViews(int recipeId);

    // ---
    
    // 3. **U P D A T E (수정)**
    
    /** 레시피 기본 정보를 수정합니다. (작성자 ID 조건 포함) */
    public int update(RecipeDto dto);
    
    /** 레시피의 모든 이미지를 삭제합니다. (수정 전 클리어 목적) */
    public int deleteRecipeImages(int recipeId);
    
    /** 레시피의 모든 재료 매핑 정보를 삭제합니다. (CASCADE로 상세 재료도 삭제) */
    public int deleteIngredientMaps(int recipeId);

    // ---
    
    // 4. **D E L E T E (삭제)**
    
    /** 특정 RECIPE_ID의 레시피를 삭제합니다. (CASCADE로 이미지/재료도 삭제) */
    public int delete(int recipeId);
}
