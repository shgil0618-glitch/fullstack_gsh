package project2.dto;

import lombok.Data;

@Data
public class RecipeIngreMap {
    private int recipeId;
    private int ingreMapId;

}
