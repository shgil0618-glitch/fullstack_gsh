package project2.dto;

import lombok.Data;

@Data
public class RecipeIngre {
    private int ingreMapId;
    private String ingreName;
    private String ingreNum;
}
