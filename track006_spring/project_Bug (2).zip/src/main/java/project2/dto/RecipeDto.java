package project2.dto;

import java.sql.Date;
import java.util.List;

import lombok.Data;

@Data
public class RecipeDto {
    private int recipeId;
    private int appUserId;       // BUG.APPUSERID 참조
    private String title;
    private int category; // CATEGORY 테이블 JOIN 결과
    private String image;
    private int cookTime;
    private String difficulty;
    private int servings;
    private String description;
    private String instructions;
    private Date createdAt;
    private Date updatedAt;
    private int views;
    private String nickname;       // BUG.NICKNAME JOIN 결과

    // 연관 객체
    private List<RecipeImage> images;
    private List<RecipeIngre> ingredients;

    // getter/setter
}
