package project2.dto;

import lombok.Data;

@Data
public class RecipeImage {
    private int recipeId;
    private String rurl;
}
