package project2.service;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import project2.dao.RecipeDao;
import project2.dto.RecipeDto;
import project2.dto.RecipeImage;
import project2.dto.RecipeIngre;
import project2.dto.RecipeIngreMap;

@Service
public class RecipeServiceImpl implements RecipeService {

    @Autowired
    RecipeDao dao;

    // 파일 업로드 경로 설정 (예시와 동일하게 C:/file/ 사용)
    private static final String UPLOAD_PATH = "C:/file/";

    // --- C R E A T E (등록) ---
    @Override
    @Transactional // 다중 DB 작업이므로 트랜잭션 관리
    public int insertRecipe(RecipeDto dto, List<MultipartFile> files) {
        int result = 0;

        // 1. RECIPES 테이블에 기본 정보 삽입
        // RECIPE_ID가 생성되어 dto에 반환됨 (XML 설정에 따라)
        result += dao.insert(dto);

        int recipeId = dto.getRecipeId(); // 생성된 ID 획득

        // 2. RECIPES_IMG 테이블에 이미지 정보 삽입 (파일 처리)
        if (files != null && !files.isEmpty()) {
            for (MultipartFile file : files) {
                if (!file.isEmpty()) {
                    String fileName = file.getOriginalFilename();
                    File img = new File(UPLOAD_PATH + fileName);
                    
                    try {
                        // 파일 저장
                        file.transferTo(img);
                        
                        // DB에 이미지 URL/경로 저장
                        RecipeImage imageDto = new RecipeImage();
                        imageDto.setRecipeId(recipeId);
                        imageDto.setRurl(fileName);
                        result += dao.insertRecipeImage(imageDto);
                        
                    } catch (IOException e) {
                        e.printStackTrace();
                        // 파일 처리 오류 시 런타임 예외 발생시켜 트랜잭션 롤백 유도
                        throw new RuntimeException("파일 저장 중 오류 발생", e);
                    }
                }
            }
        }
        
        // 3. RECIPES_INGRE_MAP & RECIPES_INGRE 테이블에 재료 정보 삽입
        List<RecipeIngre> ingredients = dto.getIngredients();
        if (ingredients != null && !ingredients.isEmpty()) {
            // 재료 매핑 ID를 관리하기 위한 루프
            for (RecipeIngre ingre : ingredients) {
                // 3-1. RECIPES_INGRE_MAP 삽입 (INGRE_MAP_ID 획득)
                RecipeIngreMap mapDto = new RecipeIngreMap();
                mapDto.setRecipeId(recipeId);
                dao.insertIngredientMap(mapDto);
                
                int ingreMapId = mapDto.getIngreMapId(); // 생성된 ID 획득
                
                // 3-2. RECIPES_INGRE 상세 정보 삽입
                ingre.setIngreMapId(ingreMapId);
                result += dao.insertIngredientDetail(ingre);
            }
        }

        return result;
    }

    // --- R E A D (조회) ---

    @Override
    public List<RecipeDto> selectAllRecipes() {
        return dao.selectAll();
    }
    
    @Override
    public List<RecipeDto> selectMyRecipes(int appUserId) {
        return dao.selectMyRecipes(appUserId);
    }

    @Override
    @Transactional
    public RecipeDto selectRecipeDetail(int recipeId) {
        // 1. 조회수 증가
        dao.incrementRecipeViews(recipeId);
        
        // 2. 레시피 기본 정보 조회
        RecipeDto dto = dao.select(recipeId);
        
        if (dto != null) {
            // 3. 이미지 목록 조회
            List<RecipeImage> images = dao.selectRecipeImages(recipeId);
            dto.setImages(images);
            
            // 4. 재료 목록 조회
            List<RecipeIngre> ingredients = dao.selectRecipeIngredients(recipeId);
            dto.setIngredients(ingredients);
        }
        
        return dto;
    }

    // --- U P D A T E (수정) ---

    @Override
    @Transactional // 다중 DB 작업이므로 트랜잭션 관리
    public int updateRecipe(RecipeDto dto, List<MultipartFile> files) {
        int result = 0;
        int recipeId = dto.getRecipeId();
        
        // 0. 권한 확인 (선택 사항: Service 단에서 해당 레시피의 작성자와 DTO의 appUserId 비교 필요)
        // ... (실제 구현 시 권한 확인 로직을 추가해야 함) ...
        
        // 1. 레시피 기본 정보 업데이트
        result += dao.update(dto);
        
        // 2. 이미지 수정: 기존 이미지 삭제 후 새로 삽입
        dao.deleteRecipeImages(recipeId); // 기존 이미지 삭제
        
        if (files != null && !files.isEmpty()) {
            for (MultipartFile file : files) {
                 if (!file.isEmpty()) {
                    String fileName = file.getOriginalFilename();
                    File img = new File(UPLOAD_PATH + fileName);
                    
                    try {
                        file.transferTo(img); // 파일 저장
                        
                        RecipeImage imageDto = new RecipeImage();
                        imageDto.setRecipeId(recipeId);
                        imageDto.setRurl(fileName);
                        result += dao.insertRecipeImage(imageDto); // 새로운 이미지 삽입
                        
                    } catch (IOException e) {
                        e.printStackTrace();
                        throw new RuntimeException("파일 저장 중 오류 발생", e);
                    }
                }
            }
        }

        // 3. 재료 수정: 기존 재료 삭제 후 새로 삽입
        dao.deleteIngredientMaps(recipeId); // CASCADE 적용으로 recipes_ingre도 삭제됨

        List<RecipeIngre> ingredients = dto.getIngredients();
        if (ingredients != null && !ingredients.isEmpty()) {
            for (RecipeIngre ingre : ingredients) {
                // 3-1. RECIPES_INGRE_MAP 삽입 (새로운 ID 획득)
                RecipeIngreMap mapDto = new RecipeIngreMap();
                mapDto.setRecipeId(recipeId);
                dao.insertIngredientMap(mapDto);
                
                int ingreMapId = mapDto.getIngreMapId();
                
                // 3-2. RECIPES_INGRE 상세 정보 삽입
                ingre.setIngreMapId(ingreMapId);
                result += dao.insertIngredientDetail(ingre);
            }
        }

        return result;
    }

    // --- D E L E T E (삭제) ---

    @Override
    public int deleteRecipe(int recipeId, int appUserId) {
        // 0. 권한 확인 (선택 사항: 실제 구현 시 권한 확인 로직을 추가해야 함)
        // 레시피를 조회하여 작성자 ID와 appUserId가 일치하는지 확인
        // ...
        
        // 1. RECIPES 테이블 삭제 (CASCADE로 자식 테이블 자동 삭제)
        return dao.delete(recipeId);
    }
}