package com.thejoa703.dao;

public class UserManageDao {

}
