package com.thejoa703.dto;

public class UserStatus {
    public static final String ACTIVE = "ACTIVE";
    public static final String SUSPEND = "SUSPEND";
    public static final String WITHDRAW = "WITHDRAW";
}