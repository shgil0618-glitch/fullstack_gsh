package com.thejoa703.dto;

public class UserManageDto {

}
