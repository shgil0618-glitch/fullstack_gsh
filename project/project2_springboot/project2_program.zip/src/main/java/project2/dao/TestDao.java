package project2.dao;

@MyDao
public interface TestDao {

}
