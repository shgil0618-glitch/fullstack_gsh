package com.thejoa703;



import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.UUID;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.transaction.annotation.Transactional;

import com.thejoa703.dao.AppUserDao;
import com.thejoa703.dto.AppUserAuthDto;
import com.thejoa703.dto.AppUserDto;
import com.thejoa703.dto.AuthDto;
import com.thejoa703.service.AppUserService;


@SpringBootTest
@Transactional	//테스트 실행중 발생 db변경 자동 롤백!
class Boot001ApplicationTests2_User { 
	
	@Autowired AppUserDao dao;
	@Autowired AppUserService service;
	
	
	@Disabled @Test
	public void testService() {
		String email = UUID.randomUUID().toString() + "@test.com";
		
		//1. 회원가입
		AppUserDto user = new AppUserDto();
		user.setEmail(email);
		user.setPassword("pw123");
		user.setMobile("01025807894");
		user.setNickname("nickname");
		user.setProvider("local");
		user.setProviderId("local_"+UUID.randomUUID());
		
		MockMultipartFile file = new MockMultipartFile("file", "test.txt","text/plain","data".getBytes());
		int insertResult = service.insert(file, user);
		assertEquals(1, insertResult);
		
		//2.로그인테스트(readAuth) + 마이페이지
		//2-1. 로그인
		AppUserAuthDto login = service.readAuth(email, "local");
		assertNotNull(login);
		assertEquals(email, login.getEmail());
		assertTrue(login.getAuthList().stream().anyMatch(a->"ROLE_MEMBER".equals(a.getAuth())));
		//2-2. 마이페이지
		AppUserDto mypage = service.selectEmail(email, "local");
		assertNotNull(mypage);
		assertEquals("nickname", mypage.getNickname());
		
		//3. 업데이트
		AppUserDto updateDto = new AppUserDto();
		updateDto.setEmail(email);
		updateDto.setPassword("pw123");
		updateDto.setNickname("newnickname");
		updateDto.setProvider("local");
		
		int updateResult = service.update(null, updateDto);
		assertEquals(1, updateResult);
		
		AppUserDto updateUser = service.selectEmail(email, "local");
		assertEquals("newnickname", updateUser.getNickname());
		
		//4. 유저삭제  
		AppUserDto deleteDto = new AppUserDto();
		deleteDto.setEmail(email);
		deleteDto.setPassword("pw123");
		deleteDto.setProvider("local");
		
		int deleteResult = service.delete(deleteDto, true);
		assertEquals(1, deleteResult);
		assertNull(service.selectEmail(email, "local"));
		
	}
	
	@Disabled @Test
	public void testCrudAppUserAuth() {
		//1. 회원가입 - 사용자 입력
		AppUserDto user = new AppUserDto();
		user.setEmail("qw@qw");
		user.setPassword("1");
		user.setMbtiTypeId(1);
		user.setUfile("1.png");
		user.setMobile("01012345678");
		user.setNickname("한승현");
		user.setProvider("local");
		user.setProviderId("local_001");
		int result = dao.insertAppUser(user);
		System.out.println(".........1. " + result );
		assertEquals(1, result);	//회원가입성공 확인(자동확인)
		
		//2. 		- 권한 입력
		AuthDto auth = new AuthDto();
		auth.setAppUserId(1);
		auth.setEmail("qw@qw");
		auth.setAuth("ROLE_USER");
		int result_auth = dao.insertAuth(auth);
		System.out.println("..........2. " + result_auth);	
		assertEquals(1, result_auth);
		
		//3. 로그인
		AppUserDto login = new AppUserDto();
		login.setEmail("qw@qw");
		login.setProvider("local");
		System.out.println("..........3. " + dao.readAuthByEmail(login));
		assertNotNull(dao.readAuthByEmail(login));	//notnull
		
		//4. 아이디 중복
		AppUserDto iddouble = new AppUserDto();
		iddouble.setEmail("qw@qw");
		iddouble.setProvider("local");
		System.out.println("..........4. " + dao.iddoubleByEmail(iddouble));
		assertTrue(dao.iddoubleByEmail(iddouble)>0);
		
		//5. 마이페이지
		AppUserDto mypage = new AppUserDto();
		mypage.setEmail("qw@qw");
		mypage.setProvider("local");
		AppUserDto findUser = dao.findByEmail(mypage);
		int id = findUser.getAppUserId();
		System.out.println("..........5. " + findUser);
		assertNotNull(findUser);   // 마이페이지 조회 성공

		//6. 수정
		AppUserDto update = new AppUserDto();
		update.setMbtiTypeId(3);
		update.setEmail("qwqw@qwqw");
		update.setAppUserId(1);
		System.out.println("..........6. " + dao.updateAppUser(update));
		assertEquals(1, dao.updateAppUser(update));   // 수정 성공

		//7. 사용자 삭제
		AppUserDto delete = new AppUserDto();
		delete.setAppUserId(84);
		System.out.println("..........7. " + dao.deleteAppUser(delete));
		assertTrue(dao.deleteAppUser(delete) >= 0);   // 삭제 실행 확인

		//8. 권한 삭제
		AuthDto dauth = new AuthDto();
		dauth.setEmail("qw@qw");
		int deleteauthresult = dao.deleteAuth(dauth);
		System.out.println("..........8. " + deleteauthresult);
		assertEquals(1, deleteauthresult);       // 권한 삭제 성공

		
		
	}
 
	
}

