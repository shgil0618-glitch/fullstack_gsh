package com.thejoa703.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

	@Bean
	public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
		http	
		.authorizeHttpRequests(auth->auth //1.허용 경로
				// 누구나 접근 가능
				.antMatchers("/users/join", "/users/login", "/users/iddouble").permitAll()
				//로그인한 유저들만 접근 가능
				.antMatchers("/users/mypage","/users/update","/users/delete").authenticated()
				.anyRequest().permitAll()
				)	
		//2.로그인처리
		.formLogin(form-> form
				.loginPage("/user/login") //로그인폼
				.loginProcessingUrl("/users/loginProc")	//로그인경로
				.defaultSuccessUrl("/users/mypage",true) //로그인 성공시경로
				.failureUrl("/users/fail") // 로그인 실패시 경로
				.permitAll()
				)
		//3.로그아웃
		.logout(logout->logout
				.logoutRequestMatcher(new AntPathRequestMatcher("/users/logout"))
				.logoutSuccessUrl("/users/login")
				.invalidateHttpSession(true)
				.permitAll()
				)	
		//4.csrf 예외처리
		.csrf( csrf -> csrf.ignoringAntMatchers("/users/join", "/users/update", "/users/delete"));		
		return http.build();
	}
	
	@Bean
	public AuthenticationManager authenticationManager(AuthenticationConfiguration authConfig) throws Exception {
		return authConfig.getAuthenticationManager();
	}
	
	
}
