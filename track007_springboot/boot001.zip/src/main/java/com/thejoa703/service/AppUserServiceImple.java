package com.thejoa703.service;

import java.io.IOException;
import java.nio.channels.IllegalSelectorException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.thejoa703.dao.AppUserDao;
import com.thejoa703.dto.AppUserAuthDto;
import com.thejoa703.dto.AppUserDto;
import com.thejoa703.dto.AuthDto;
import com.thejoa703.util.UtilUpload;


@Service
public class AppUserServiceImple implements AppUserService {
	
	@Autowired private AppUserDao userDao;
	@Autowired private PasswordEncoder passwordEncoder;
	@Autowired private UtilUpload utilUpload;

	/* insert,upload 파일업로드(공통) */
	private String uploadFile(MultipartFile file, String existingFile) {
		if(file != null && !file.isEmpty()) {	//파일 존재한다면
			try {
				return utilUpload.fileUpload(file);
			} catch (IOException e) {
				throw new RuntimeException("파일업로드 실패", e);
			}
		}
		return existingFile;
	}
	
	@Transactional
	@Override
	public int insert(MultipartFile file, AppUserDto dto) {
		//1. 파일업로드
		dto.setProvider("local");
		dto.setPassword(passwordEncoder.encode(dto.getPassword()));
		dto.setUfile(uploadFile(file,null));
		
		if(userDao.iddoubleByEmail(dto)>0) {
			throw new IllegalStateException("이미 존재하는 계정입니다.");
		}
		//2. 유저 insert
		int result = userDao.insertAppUser(dto);
		//3. 권한 insert
		if(result>0) {userDao.insertAuth(new AuthDto(dto.getEmail(),"ROLE_MEMBER"));}
		
		return result;
	}

	@Transactional
	@Override
	public int update(MultipartFile file, AppUserDto dto) {
		dto.setProvider("local");
		AppUserDto dbUser = userDao.findByEmail(dto);
		if(dbUser == null) {return 0;}
		if(!passwordEncoder.matches(dto.getPassword(), dbUser.getPassword())) { return 0;}
		
		dto.setAppUserId(dbUser.getAppUserId());	//id셋팅
		dto.setUfile(uploadFile(file,dbUser.getUfile()));
		dto.setNickname(dto.getNickname()==null? dbUser.getNickname() : dto.getNickname());
		dto.setMobile(dto.getMobile()==null? dbUser.getMobile() : dto.getMobile());
		dto.setPassword(dbUser.getPassword());
		
		return userDao.updateAppUser(dto);
	}

	@Override
	public int delete(AppUserDto dto, boolean requirePasswordCheck) {
		AppUserDto dbUser = userDao.findByEmail(dto);
		if(dbUser == null) {return 0;}
		if(requirePasswordCheck) { //local
			if(dto.getPassword()==null || !passwordEncoder.matches(dto.getPassword(), dbUser.getPassword())) {
				return 0;
			}
		}
		
		dto.setAppUserId(dbUser.getAppUserId());
		userDao.deleteAuth(new AuthDto(dto.getEmail(), "ROLE_MEMBER"));
		return userDao.deleteAppUser(dto);
	}

	@Override
	public AppUserAuthDto readAuth(String email, String provider) {
		return userDao.readAuthByEmail(new AppUserDto(email,provider));
	}

	@Override
	public AppUserDto selectEmail(String email, String provider) {
		return userDao.findByEmail(new AppUserDto(email,provider));
	}

	@Override
	public int iddouble(String email, String provider) {
		return userDao.iddoubleByEmail(new AppUserDto(email,provider));
	}

	@Override
	public boolean matchesPassword(String email, String provider, String rawPassword) {
		AppUserDto dbUser = userDao.findByEmail(new AppUserDto(email,provider));	//db유저 찾기
		// db비번과 매칭하는 user가 true
		return dbUser!=null && dbUser.getPassword() != null && passwordEncoder.matches(rawPassword, dbUser.getPassword());
		
	}

}
