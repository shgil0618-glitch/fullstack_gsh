package com.thejoa703.service;

public interface TestService {
	public String readTime();
}
